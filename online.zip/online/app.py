from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import json
import os
import random
import threading
import difflib
from flask_mail import Mail, Message
from datetime import datetime
from time import time

app = Flask(__name__)
app.secret_key = "your_secret_key_here"  # Change this to a strong secret key!

# --- Admin credentials ---
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123"

# --- Flask-Mail Config (Gmail SMTP) ---
app.config.update(
    MAIL_SERVER='smtp.gmail.com',
    MAIL_PORT=587,
    MAIL_USE_TLS=True,
    MAIL_USERNAME='subzonebd15@gmail.com',   # Your Gmail address here
    MAIL_PASSWORD='zxfzzqcbgicfpwcw'         # Your Gmail App Password here
)
mail = Mail(app)

# --- Utility functions ---

def load_users():
    if os.path.exists("users.json"):
        with open("users.json", "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_users(users):
    with open("users.json", "w", encoding="utf-8") as f:
        json.dump(users, f, indent=2)

def load_products():
    if os.path.exists("prices.json"):
        with open("prices.json", "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def load_orders():
    if os.path.exists("orders.json"):
        with open("orders.json", "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def save_orders(orders):
    with open("orders.json", "w", encoding="utf-8") as f:
        json.dump(orders, f, indent=2)

def send_async_email(app, msg):
    with app.app_context():
        mail.send(msg)

def send_email(subject, recipients, body):
    try:
        msg = Message(subject, sender=app.config['MAIL_USERNAME'], recipients=recipients, body=body)
        threading.Thread(target=send_async_email, args=(app, msg)).start()
    except Exception as e:
        print("Email send error:", e)

def send_verification_code(email, otp):
    body = f"""Hi {email},

Your verification code is: {otp}
It will expire after 5 minutes.

SubZoneBD Team
"""
    send_email("Email Verification Code - SubZoneBD", [email], body)

# --- Routes ---

@app.route("/")
def index():
    query = request.args.get("search", "").lower()
    all_products = load_products()
    logged_in = "username" in session

    def is_match(q, t):
        return q in t.lower() or difflib.SequenceMatcher(None, q, t.lower()).ratio() > 0.5

    if query:
        products = {k: v for k, v in all_products.items() if is_match(query, v.get("name", ""))}
    else:
        products = all_products

    return render_template("index.html", products=products, logged_in=logged_in, username=session.get("username"))

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "").strip()

        if not email or not password:
            return render_template("signup.html", error="Please fill in all fields.")
        if not email.endswith("@gmail.com"):
            return render_template("signup.html", error="Only Gmail addresses are allowed.")

        users = load_users()
        if email in users:
            return render_template("signup.html", error="Email already registered.")

        otp = str(random.randint(100000, 999999))
        session["pending_email"] = email
        session["pending_password"] = password
        session["otp_code"] = otp
        session["otp_expiry"] = time() + 300

        send_verification_code(email, otp)
        flash(f"Verification code sent to {email}. Please check your email.", "info")
        return redirect(url_for("verify_email"))

    return render_template("signup.html")

@app.route("/verify_email", methods=["GET", "POST"])
def verify_email():
    email = session.get("pending_email")
    otp_code = session.get("otp_code")
    expiry = session.get("otp_expiry")
    password = session.get("pending_password")

    if not email or not otp_code or not password:
        flash("Signup session expired. Please signup again.", "danger")
        return redirect(url_for("signup"))

    if request.method == "POST":
        if "resend" in request.form:
            new_otp = str(random.randint(100000, 999999))
            session["otp_code"] = new_otp
            session["otp_expiry"] = time() + 300
            send_verification_code(email, new_otp)
            flash("New verification code sent.", "info")
            return redirect(url_for("verify_email"))

        code = request.form.get("code", "").strip()
        if code == otp_code and time() < expiry:
            users = load_users()
            users[email] = {"password": password, "verified": True}
            save_users(users)

            session.pop("pending_email", None)
            session.pop("pending_password", None)
            session.pop("otp_code", None)
            session.pop("otp_expiry", None)

            session["username"] = email
            flash("✅ Email verified successfully!", "success")
            return redirect(url_for("index"))
        else:
            flash("❌ Invalid or expired code.", "danger")

    return render_template("verify_email.html", email=email)

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("username", "").strip().lower()
        password = request.form.get("password", "").strip()
        users = load_users()
        user = users.get(email)

        if user and user.get("password") == password:
            if user.get("verified"):
                session["username"] = email
                flash("Logged in successfully!", "success")
                return redirect(url_for("index"))
            else:
                flash("Email not verified. Please signup again.", "danger")
        else:
            flash("Invalid email or password.", "danger")

    return render_template("login.html")

@app.route("/logout")
def logout():
    session.pop("username", None)
    session.pop("admin_logged_in", None)
    flash("Logged out successfully.", "info")
    return redirect(url_for("index"))

@app.route("/forgot", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        users = load_users()
        user = users.get(email)

        if user and user.get("verified"):
            otp = str(random.randint(100000, 999999))
            user["otp_code"] = otp
            user["otp_expiry"] = time() + 300
            save_users(users)

            try:
                body = f"Your password reset code is: {otp}\nIt will expire in 5 minutes."
                send_email("Password Reset Code - SubZoneBD", [email], body)

                session["forgot_email"] = email
                flash("Password reset code sent.", "info")
                return redirect(url_for("reset_password"))
            except Exception as e:
                print("Email error:", e)
                flash("Failed to send email.", "danger")
        else:
            flash("Email not found or not verified.", "danger")

    return render_template("forgot_password.html")

@app.route("/reset", methods=["GET", "POST"])
def reset_password():
    email = session.get("forgot_email")
    if not email:
        flash("Session expired. Try again.", "danger")
        return redirect(url_for("forgot_password"))

    users = load_users()
    user = users.get(email)

    if request.method == "POST":
        code = request.form.get("code", "").strip()
        new_password = request.form.get("new_password", "").strip()

        if user and user.get("otp_code") == code and time() < user.get("otp_expiry", 0):
            user["password"] = new_password
            user.pop("otp_code", None)
            user.pop("otp_expiry", None)
            save_users(users)

            session.pop("forgot_email", None)
            flash("Password reset successful!", "success")
            return redirect(url_for("login"))
        else:
            flash("Invalid or expired code.", "danger")

    return render_template("reset_password.html", email=email)

@app.route("/product/<product_key>")
def product_page(product_key):
    products = load_products()
    if product_key not in products:
        return "Product not found", 404
    product = products[product_key]
    images = product.get("images") or [product.get("image", "default.png")]
    logged_in = "username" in session
    return render_template("product.html", product=product, product_key=product_key, images=images, logged_in=logged_in, username=session.get("username"))

@app.route("/submit_order", methods=["POST"])
def submit_order():
    if "username" not in session:
        return jsonify({"success": False, "message": "You must be logged in to order."})

    data = request.get_json()
    required_fields = ["product_key", "name", "phone", "email", "address", "method", "transaction_id"]
    if not data or not all(data.get(field) for field in required_fields):
        return jsonify({"success": False, "message": "Please fill all the required fields."})

    product_key = data["product_key"]
    products = load_products()
    if product_key not in products:
        return jsonify({"success": False, "message": "Product does not exist."})

    product = products[product_key]
    if not product.get("stock", True):
        return jsonify({"success": False, "message": "Product is out of stock."})

    delivery_charge = product.get("delivery_charge", 0)
    total_price = product["price"] + delivery_charge

    orders = load_orders()
    now_ts = int(time())

    for o in orders:
        if o["username"] == session["username"] and abs(now_ts - o["timestamp"]) < 20:
            return jsonify({"success": False, "message": "Order already placed recently. Please wait a moment."})

    order = {
        "id": len(orders) + 1,
        "username": session["username"],
        "product": product["name"],
        "price": product["price"],
        "delivery_charge": delivery_charge,
        "total_price": total_price,
        "name": data["name"],
        "phone": data["phone"],
        "email": data["email"],
        "address": data["address"],
        "method": data["method"],
        "trx": data["transaction_id"],
        "status": "Processing",
        "delivery": "Not set",
        "location": "Not set",
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "timestamp": now_ts,
        "cancelled": False
    }
    orders.append(order)
    save_orders(orders)

    try:
        body = f"""
Dear {order['name']},

Thank you for your order at SubZoneBD!

Order Details:
Product: {order['product']}
Price: {order['price']} Tk
Delivery Charge: {order['delivery_charge']} Tk
Total Paid: {order['total_price']} Tk
Payment Method: {order['method']}
Transaction ID: {order['trx']}
Delivery Address: {order['address']}
Status: {order['status']}

We will notify you when your order is shipped.

Best regards,
SubZoneBD Team
"""
        send_email("Order Confirmation - SubZoneBD", [order["email"]], body)
    except Exception as e:
        print(f"Email sending error: {e}")

    return jsonify({"success": True, "redirect": "/"})

@app.route("/my_orders")
def my_orders():
    if "username" not in session:
        return redirect(url_for("login"))
    username = session["username"]
    orders = load_orders()
    user_orders = [o for o in orders if o["username"] == username]
    now_ts = int(time())
    return render_template("my_orders.html", orders=user_orders, username=username, now_ts=now_ts)

@app.route("/cancel_order/<int:order_id>", methods=["POST"])
def cancel_order(order_id):
    if "username" not in session:
        return jsonify({"success": False, "message": "Login required."})
    orders = load_orders()
    for order in orders:
        if order["id"] == order_id and order["username"] == session["username"]:
            now_ts = int(time())
            if order.get("cancelled"):
                return jsonify({"success": False, "message": "Order already cancelled."})
            if now_ts - order.get("timestamp", 0) > 1380:
                return jsonify({"success": False, "message": "Cancellation period expired."})
            order["cancelled"] = True
            order["status"] = "Cancelled"
            save_orders(orders)
            return jsonify({"success": True})
    return jsonify({"success": False, "message": "Order not found."})

@app.route("/admin", methods=["GET", "POST"])
def admin():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session["admin_logged_in"] = True
            return redirect(url_for("admin_dashboard"))
        else:
            flash("Invalid admin credentials", "danger")
            return render_template("admin_login.html")
    if not session.get("admin_logged_in"):
        return render_template("admin_login.html")
    return redirect(url_for("admin_dashboard"))

@app.route("/admin/dashboard")
def admin_dashboard():
    if not session.get("admin_logged_in"):
        return redirect(url_for("admin"))
    orders = load_orders()
    return render_template("admin.html", orders=orders)

@app.route("/admin_logout")
def admin_logout():
    session.pop("admin_logged_in", None)
    flash("Admin logged out.", "info")
    return redirect(url_for("index"))

@app.route("/update_status", methods=["POST"])
def update_status():
    if not session.get("admin_logged_in"):
        return jsonify({"success": False, "message": "Admin login required."})
    data = request.get_json()
    order_id = int(data.get("id", 0))
    status = data.get("status", "")
    delivery = data.get("delivery", "")
    location = data.get("location", "")
    orders = load_orders()
    for o in orders:
        if o["id"] == order_id:
            o["status"] = status
            o["delivery"] = delivery
            o["location"] = location
            save_orders(orders)
            return jsonify({"success": True})
    return jsonify({"success": False, "message": "Order not found."})

@app.route("/delete_order", methods=["POST"])
def delete_order():
    if not session.get("admin_logged_in"):
        return jsonify({"success": False, "message": "Admin login required."})
    data = request.get_json()
    order_id = int(data.get("id", 0))
    orders = load_orders()
    new_orders = [o for o in orders if o["id"] != order_id]
    if len(new_orders) < len(orders):
        save_orders(new_orders)
        return jsonify({"success": True})
    return jsonify({"success": False, "message": "Order not found."})

if __name__ == "__main__":
    app.run(debug=True)
